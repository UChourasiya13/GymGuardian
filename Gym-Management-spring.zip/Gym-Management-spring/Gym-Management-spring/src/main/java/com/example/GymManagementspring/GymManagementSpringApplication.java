package com.example.GymManagementspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymManagementSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymManagementSpringApplication.class, args);
	}

}
