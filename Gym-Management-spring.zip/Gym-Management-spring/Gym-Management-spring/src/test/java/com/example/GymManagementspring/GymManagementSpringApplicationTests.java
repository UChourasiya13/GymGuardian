package com.example.GymManagementspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymManagementSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
